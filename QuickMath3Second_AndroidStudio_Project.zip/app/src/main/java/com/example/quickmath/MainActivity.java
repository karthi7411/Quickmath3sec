package com.example.quickmath;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends Activity {
    private LinearLayout root, options;
    private TextView timerText, questionText, scoreText, feedbackText, progressText;
    private CountDownTimer timer;
    private final Random random = new Random();
    private int score = 0, questionNo = 0, correctAnswer = 0;
    private boolean answered = false, gameOver = false;
    private static final int BG = Color.rgb(23, 21, 43);
    private static final int PURPLE = Color.rgb(103, 80, 164);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showStartScreen();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(20); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackground(bg(PURPLE, 28));
        return b;
    }

    private void setup(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(24, 28, 24, 28);
        root.setBackgroundColor(BG);
        setContentView(root);
        TextView heading = text(title, 27, Color.WHITE, true);
        root.addView(heading, new LinearLayout.LayoutParams(-1, 70));
    }

    private void showStartScreen() {
        stopTimer();
        setup("⚡ QUICK MATH");
        TextView intro = text("Answer each question before the 3-second timer runs out.", 18, Color.LTGRAY, false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(8, 22, 8, 32); root.addView(intro, p);
        TextView modes = text("Addition  +  Subtraction", 21, Color.WHITE, true);
        root.addView(modes, new LinearLayout.LayoutParams(-1, 65));
        Button start = button("START CHALLENGE");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 68);
        bp.setMargins(0, 35, 0, 0); root.addView(start, bp);
        start.setOnClickListener(v -> { score = 0; questionNo = 0; gameOver = false; nextQuestion(); });
    }

    private void nextQuestion() {
        stopTimer();
        if (gameOver) return;
        questionNo++; answered = false;
        boolean add = random.nextBoolean();
        int a = random.nextInt(50) + 1, b = random.nextInt(50) + 1;
        if (!add && b > a) { int tmp = a; a = b; b = tmp; }
        correctAnswer = add ? a + b : a - b;

        setup("⚡ QUICK MATH");
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, 52);
        timerText = text("3", 34, Color.rgb(255, 193, 7), true);
        root.addView(timerText, mp);
        progressText = text("QUESTION " + questionNo, 14, Color.LTGRAY, true);
        root.addView(progressText, new LinearLayout.LayoutParams(-1, 32));
        questionText = text(a + (add ? "  +  " : "  −  ") + b + "  =  ?", 38, Color.WHITE, true);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, 120);
        qp.setMargins(0, 12, 0, 12); root.addView(questionText, qp);
        scoreText = text("SCORE: " + score, 17, Color.LTGRAY, true);
        root.addView(scoreText, new LinearLayout.LayoutParams(-1, 42));
        feedbackText = text("Choose the correct answer", 16, Color.LTGRAY, false);
        root.addView(feedbackText, new LinearLayout.LayoutParams(-1, 42));
        options = new LinearLayout(this);
        options.setOrientation(LinearLayout.VERTICAL);
        root.addView(options, new LinearLayout.LayoutParams(-1, -2));
        addOptions();
        timer = new CountDownTimer(3000, 100) {
            public void onTick(long ms) { timerText.setText(String.valueOf((int)Math.ceil(ms / 1000.0))); }
            public void onFinish() {
                if (!answered) {
                    answered = true;
                    feedbackText.setText("⏰ Time's up! Answer: " + correctAnswer);
                    feedbackText.setTextColor(Color.rgb(255, 193, 7));
                    options.postDelayed(() -> nextQuestion(), 650);
                }
            }
        }.start();
    }

    private void addOptions() {
        int[] vals = new int[4];
        vals[0] = correctAnswer;
        for (int i = 1; i < 4; i++) {
            int candidate;
            do { candidate = correctAnswer + random.nextInt(19) - 9; }
            while (contains(vals, i, candidate));
            vals[i] = candidate;
        }
        for (int i = vals.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1), t = vals[i]; vals[i] = vals[j]; vals[j] = t;
        }
        for (int i = 0; i < 4; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = i; j < i + 2; j++) {
                final int answer = vals[j];
                Button choice = button(String.valueOf(answer));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, 72, 1);
                cp.setMargins(5, 7, 5, 7);
                row.addView(choice, cp);
                choice.setOnClickListener(v -> choose(answer));
            }
            options.addView(row);
        }
    }

    private boolean contains(int[] a, int n, int value) {
        for (int i = 0; i < n; i++) if (a[i] == value) return true;
        return false;
    }

    private void choose(int answer) {
        if (answered || gameOver) return;
        answered = true; stopTimer();
        if (answer == correctAnswer) {
            score++;
            feedbackText.setText("✓ CORRECT!");
            feedbackText.setTextColor(Color.rgb(105, 220, 150));
        } else {
            feedbackText.setText("✗ Correct answer: " + correctAnswer);
            feedbackText.setTextColor(Color.rgb(255, 130, 130));
        }
        scoreText.setText("SCORE: " + score);
        options.postDelayed(() -> nextQuestion(), 550);
    }

    private void stopTimer() { if (timer != null) { timer.cancel(); timer = null; } }

    @Override public void onBackPressed() {
        stopTimer();
        showStartScreen();
    }
}
